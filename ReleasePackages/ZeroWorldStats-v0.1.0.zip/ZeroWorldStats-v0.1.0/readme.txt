Zero World Stats
Version 0.1.0
Created by Aaron Gilbert

Installation
Extract this archive to any directory and done! Please note that .NET Framework 4 is required to run 
the application.

Usage
- To launch the app, run ZeroWorldStats.exe from any directory.
- To get the stats of a world, first browse for the world's REQ file (via the "Browse" button). Then, select the relevant game mode and plan file from the dropdowns and click "Get All".

Bugs & Suggestions
Find a bug or have a suggestion? Submit them here: https://github.com/marth8880/ZeroWorldStats/issues

License
For license information, please see the enclosed license.txt file.